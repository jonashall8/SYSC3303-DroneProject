public class Main {

    public static void main(String[] args) {
        // Initialize Scheduler
        /*
        Scheduler scheduler = new Scheduler();

        // Initialize FireIncidentSubSystem and start its thread
        FireIncidentSubSystem fireSystem = new FireIncidentSubSystem(scheduler, "src/main/resources/Sample_zone_file.csv", "src/main/resources/Sample_event_file.csv");
        Thread fireThread = new Thread(fireSystem);


        // Initialize DroneSubsystem and start its thread.
        DroneSubsystem drone1 = new DroneSubsystem(scheduler, 1);
        Thread droneThread = new Thread(drone1);
        scheduler.receiveDroneEvent(drone1);

        // Start Scheduler thread
        Thread schedulerThread = new Thread(scheduler);

        fireThread.start();
        droneThread.start();
        schedulerThread.start();
*/
    }
}